﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    static class Conection
    {
        public const string ConectionString = @"Server=.;Database=Football Betting;Integrated Security=true;";
    }
}
