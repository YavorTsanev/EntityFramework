﻿namespace P03_FootballBetting.Data
{
    static class Conection
    {
        public const string ConectionString = @"Server=.;Database=Football Betting;Integrated Security=true;";
    }
}
