﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FastFood.Web.ViewModels.Orders
{
    public class CreateOrderItemVeiwModel
    {

        public int ItemId { get; set; } 

        public string ItemName { get; set; }
    }
}
