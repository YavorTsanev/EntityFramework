﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public static class Cofigurations
    {
        public const string ConfigurationString = @"Server=.;Database=ProductShopXML;Integrated Security=true";
    }
}
