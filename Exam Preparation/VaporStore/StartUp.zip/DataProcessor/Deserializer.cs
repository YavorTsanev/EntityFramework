﻿using System.Globalization;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using VaporStore.Data.Models;
using VaporStore.DataProcessor.Dto.Import;

namespace VaporStore.DataProcessor
{
	using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using Data;

	public static class Deserializer
	{
		public static string ImportGames(VaporStoreDbContext context, string jsonString)
        {
            var sb = new StringBuilder();

            var gamesDto = JsonConvert.DeserializeObject<List<GameImportDto>>(jsonString);

            foreach (var item in gamesDto)
            {
                if (!IsValid(item) || item.Tags.Count == 0)
                {
                    sb.AppendLine("Invalid Data");
					continue;
                }

                var game = new Game
                {
                    Name = item.Name,
                    Price = item.Price,
                    ReleaseDate = DateTime.Parse(item.ReleaseDate, CultureInfo.InvariantCulture),

                };
                var dev = context.Developers.FirstOrDefault(d => d.Name == item.Developer);
                if (dev == null)
                {
                    dev = new Developer {Name = item.Developer};
                }

                game.Developer = dev;

                var genre = context.Genres.FirstOrDefault(g => g.Name == item.Genre);
                if (genre == null)
                {
                    genre = new Genre {Name = item.Genre};
                }

                game.Genre = genre;

                foreach (var tagg in item.Tags)
                {
                    var tag = context.Tags.FirstOrDefault(t => t.Name == tagg);

                    if (tag == null)
                    {
                        tag = new Tag {Name = tagg};
                    }

                    game.GameTags.Add(new GameTag
                    {
                        Tag = tag
                    });
                }

                context.Games.Add(game);
                context.SaveChanges();
                sb.AppendLine($"Added {item.Name} ({item.Genre}) with {item.Tags.Count} tags");
                
            }

			return sb.ToString().TrimEnd();
		}

		public static string ImportUsers(VaporStoreDbContext context, string jsonString)
		{
            return "TODO";
		}

		public static string ImportPurchases(VaporStoreDbContext context, string xmlString)
		{
            return "TODO";
		}

		private static bool IsValid(object dto)
		{
			var validationContext = new ValidationContext(dto);
			var validationResult = new List<ValidationResult>();

			return Validator.TryValidateObject(dto, validationContext, validationResult, true);
		}
	}
}