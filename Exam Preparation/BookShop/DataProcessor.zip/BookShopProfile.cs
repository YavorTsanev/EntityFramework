﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using BookShop.Data.Models;
using BookShop.DataProcessor.ImportDto;

namespace BookShop
{
    public class BookShopProfile : Profile
    {
        public BookShopProfile()
        {
            
        }
    }
}
