﻿using System.Linq;
using Cinema.DataProcessor.ExportDto;
using Newtonsoft.Json;
using ProductShop;

namespace Cinema.DataProcessor
{
    using System;

    using Data;

    public class Serializer
    {
        public static string ExportTopMovies(CinemaContext context, int rating)
        {
            //Export top 10 movies which have rating more or equal to the given and have at least one projection with sold tickets.For each movie, export its name, rating formatted to the second digit, total incomes formatted same way and customers. For each customer, export its first name, last name and balance formatted to the second digit. Order the customers by balance(descending by the formatted string, not the balance itselft), then by first name(ascending) and last name(ascending).Take first 10 records ordered by rating(descending), then by total incomes(descending).

            var movies = context.Movies.ToList().Where(m => m.Rating >= rating && m.Projections.Any(p => p.Tickets.Count > 0))
                .Select(m => new
                {
                    MovieName = m.Title,
                    Rating = m.Rating.ToString("f2"),
                    TotalIncomes = m.Projections.Sum(p => p.Tickets.Sum(t => t.Price)).ToString("f2"),
                    Customers = m.Projections.SelectMany(p => p.Tickets.Select(t => t.Customer)).Select(c => new
                    {
                        c.FirstName,
                        c.LastName,
                        Balance = c.Balance.ToString("f2")
                    }).ToList().OrderByDescending(x => x.Balance).ThenBy(x => x.FirstName).ThenBy(x => x.LastName).ToList()
                }).ToList().Take(10).OrderByDescending(x => x.Rating).ThenByDescending(x => x.TotalIncomes).ToList();

            return JsonConvert.SerializeObject(movies, Formatting.Indented);
        }

        public static string ExportTopCustomers(CinemaContext context, int age)
        {
            //Export customers with age above or equal to the given. For each customer, export their first name, last name, spent money for tickets(formatted to the second digit) and spent time(in format: "hh\:mm\:ss").Take first 10 records and order the result by spent money in descending order.

            var customers = context.Customers.Where(c => c.Age >= age).Select(c => new CustomerExportDto
            {
                FirstName = c.FirstName,
                LastName = c.LastName,
                SpentMoney = c.Tickets.Select(t => t.Price).Sum().ToString("f2"),
                //SpentTime = c.Tickets.Sum(t => t.Projection.Movie.Duration)
            }).ToList();

            return XmlConverter.Serialize(customers, "Customers");
        }
    } 
}