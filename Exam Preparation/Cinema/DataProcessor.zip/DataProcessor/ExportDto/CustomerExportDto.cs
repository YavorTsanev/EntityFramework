﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Cinema.DataProcessor.ExportDto
{
    [XmlType("Customer")]
    public class CustomerExportDto
    {
        [XmlAttribute]
        public string FirstName { get; set; }

        [XmlAttribute]
        public string LastName { get; set; }

        public string SpentMoney { get; set; }

        public long SpentTime { get; set; }
    }

    //<Customer FirstName = "Marjy" LastName="Starbeck">
    //<SpentMoney>82.65</SpentMoney>
    //<SpentTime>12:10:00</SpentTime>
    //</Customer>

}
