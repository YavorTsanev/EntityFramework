﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Data
{
    public static class Configuration
    {
        public const string ConectionString = @"Server=.;Database=BookShop;Integrated Security=true";
    }
}
