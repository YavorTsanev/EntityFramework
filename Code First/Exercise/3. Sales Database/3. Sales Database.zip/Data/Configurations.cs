﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public static class Configurations
    {
        public const string ConectionString = "Server=.;Database=Sales;Integrated Security=true";
    }
}
