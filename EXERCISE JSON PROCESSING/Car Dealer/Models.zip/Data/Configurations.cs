﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.Data
{
    static class Configurations
    {
        public const string CofigarationString = @"Server=.;Database=CarDealer;Integrated Security=true;";
    }
}
