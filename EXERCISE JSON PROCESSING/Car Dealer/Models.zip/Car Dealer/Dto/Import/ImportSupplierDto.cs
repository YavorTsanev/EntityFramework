﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.Dto.Import
{
    public class ImportSupplierDto
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}
